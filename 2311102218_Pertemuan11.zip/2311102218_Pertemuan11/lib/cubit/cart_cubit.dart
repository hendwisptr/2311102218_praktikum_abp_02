import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/product.dart';
import 'cart_state.dart';

class CartCubit extends Cubit<CartState> {
  CartCubit() : super(const CartLoaded(items: {}));

  void addToCart(Product product) {
    if (state is CartLoaded) {
      final currentItems = Map<Product, int>.from((state as CartLoaded).items);
      if (currentItems.containsKey(product)) {
        currentItems[product] = currentItems[product]! + 1;
      } else {
        currentItems[product] = 1;
      }
      emit(CartLoaded(items: currentItems));
    }
  }

  void removeFromCart(Product product) {
    if (state is CartLoaded) {
      final currentItems = Map<Product, int>.from((state as CartLoaded).items);
      if (currentItems.containsKey(product)) {
        if (currentItems[product]! > 1) {
          currentItems[product] = currentItems[product]! - 1;
        } else {
          currentItems.remove(product);
        }
        emit(CartLoaded(items: currentItems));
      }
    }
  }

  void removeProductCompletely(Product product) {
    if (state is CartLoaded) {
      final currentItems = Map<Product, int>.from((state as CartLoaded).items);
      currentItems.remove(product);
      emit(CartLoaded(items: currentItems));
    }
  }

  void clearCart() {
    emit(const CartLoaded(items: {}));
  }
}
