import 'package:equatable/equatable.dart';
import '../models/product.dart';

abstract class CartState extends Equatable {
  const CartState();

  @override
  List<Object?> get props => [];
}

class CartInitial extends CartState {
  const CartInitial();
}

class CartLoaded extends CartState {
  final Map<Product, int> items;

  const CartLoaded({required this.items});

  double get totalPrice {
    return items.entries.fold(0.0, (sum, entry) => sum + (entry.key.price * entry.value));
  }

  int get totalItems {
    return items.values.fold(0, (sum, qty) => sum + qty);
  }

  @override
  List<Object?> get props => [items];
}
