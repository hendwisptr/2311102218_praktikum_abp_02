import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';

class Product extends Equatable {
  final String id;
  final String name;
  final double price;
  final String description;
  final IconData icon;
  final Color themeColor;

  const Product({
    required this.id,
    required this.name,
    required this.price,
    required this.description,
    required this.icon,
    required this.themeColor,
  });

  @override
  List<Object?> get props => [id, name, price, description, icon, themeColor];
}
