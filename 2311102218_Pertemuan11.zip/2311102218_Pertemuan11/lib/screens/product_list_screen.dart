import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/product.dart';
import '../cubit/cart_cubit.dart';
import '../cubit/cart_state.dart';
import 'cart_screen.dart';

class ProductListScreen extends StatelessWidget {
  const ProductListScreen({super.key});

  static final List<Product> _products = [
    const Product(
      id: '1',
      name: 'iPhone 15 Pro',
      price: 999.00,
      description: 'Titanium design, A17 Pro chip, customizable Action button.',
      icon: Icons.phone_iphone_rounded,
      themeColor: Color(0xFF607D8B),
    ),
    const Product(
      id: '2',
      name: 'MacBook Pro M3',
      price: 1999.00,
      description: 'Stunning Liquid Retina XDR display, up to 22 hours of battery life.',
      icon: Icons.laptop_mac_rounded,
      themeColor: Color(0xFF3F51B5),
    ),
    const Product(
      id: '3',
      name: 'iPad Pro M4',
      price: 999.00,
      description: 'Thinnest Apple product ever, breakthrough Ultra Retina XDR display.',
      icon: Icons.tablet_mac_rounded,
      themeColor: Color(0xFF009688),
    ),
    const Product(
      id: '4',
      name: 'Apple Watch Ultra 2',
      price: 799.00,
      description: 'The ultimate sports watch. Rugged titanium case, dual-frequency GPS.',
      icon: Icons.watch_rounded,
      themeColor: Color(0xFFFF5722),
    ),
    const Product(
      id: '5',
      name: 'AirPods Max',
      price: 549.00,
      description: 'High-fidelity audio, Active Noise Cancellation, Transparency mode.',
      icon: Icons.headphones_rounded,
      themeColor: Color(0xFFE91E63),
    ),
    const Product(
      id: '6',
      name: 'Apple Vision Pro',
      price: 3499.00,
      description: 'Revolutionary spatial computer that blends digital content with the physical world.',
      icon: Icons.visibility_rounded,
      themeColor: Color(0xFF9C27B0),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'Tech Store',
          style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black87,
        actions: [
          BlocBuilder<CartCubit, CartState>(
            builder: (context, state) {
              int totalItems = 0;
              if (state is CartLoaded) {
                totalItems = state.totalItems;
              }

              return Padding(
                padding: const EdgeInsets.only(right: 16.0, top: 8.0),
                child: Badge(
                  label: Text(totalItems.toString()),
                  isLabelVisible: totalItems > 0,
                  backgroundColor: const Color(0xFFE91E63),
                  child: IconButton(
                    icon: const Icon(Icons.shopping_bag_outlined, size: 28),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const CartScreen(),
                        ),
                      );
                    },
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Exclusive Devices',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF2D3748),
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Get the best hardware with high-performance state management.',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.72,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: _products.length,
                itemBuilder: (context, index) {
                  final product = _products[index];
                  return _buildProductCard(context, product);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductCard(BuildContext context, Product product) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: product.themeColor.withValues(alpha: 0.08),
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  child: Center(
                    child: Icon(
                      product.icon,
                      size: 64,
                      color: product.themeColor,
                    ),
                  ),
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: BlocBuilder<CartCubit, CartState>(
                    builder: (context, state) {
                      int quantity = 0;
                      if (state is CartLoaded) {
                        quantity = state.items[product] ?? 0;
                      }

                      if (quantity > 0) {
                        return Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: product.themeColor,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '$quantity In Cart',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        );
                      }
                      return const SizedBox.shrink();
                    },
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Color(0xFF2D3748),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  product.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '\$${product.price.toStringAsFixed(0)}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                        color: Color(0xFF1A202C),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        context.read<CartCubit>().addToCart(product);
                        ScaffoldMessenger.of(context).clearSnackBars();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('${product.name} added to cart!'),
                            duration: const Duration(seconds: 1),
                            action: SnackBarAction(
                              label: 'UNDO',
                              onPressed: () {
                                context.read<CartCubit>().removeFromCart(product);
                              },
                            ),
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(50),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1A202C),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.add,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
