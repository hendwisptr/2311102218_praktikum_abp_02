# LAPORAN PRAKTIKUM
## MODUL 15: STATE MANAGEMENT (BLOC/CUBIT)

**Nama Mahasiswa:** [Nama Anda]  
**NIM:** 2311102218  
**Mata Kuliah:** Aplikasi Bergerak dan Pervasive (ABP)  
**Program Studi:** S1 Informatika  

---

### I. DESKRIPSI TUGAS
Praktikum ini bertujuan untuk membuat sebuah aplikasi Flutter sederhana yang menerapkan konsep **State Management** menggunakan **Cubit** (turunan dari pustaka BLoC). Spesifikasi tugas meliputi:
1. **Daftar Produk**: Menampilkan minimal 5 produk (dalam proyek ini diimplementasikan 6 produk teknologi eksklusif) dengan detail nama, deskripsi, harga, dan visual representatif.
2. **Pengelolaan Keranjang Belanja**: Implementasi fitur untuk menambah dan mengurangi produk dari keranjang belanja secara real-time.
3. **Sinkronisasi Real-Time**: Tampilan jumlah total item pada keranjang yang diperbarui seketika ketika terjadi perubahan state (baik di menu katalog utama maupun di halaman rincian keranjang).
4. **Komponen BLoC**: Menggunakan `BlocProvider` untuk mendistribusikan Cubit ke widget tree, serta `BlocBuilder` untuk menangkap perubahan state dan merender ulang UI yang terpengaruh.

---

### II. STRUKTUR & PENJELASAN KODE SUMBER

Aplikasi dibagi menjadi beberapa modul file terstruktur guna menjaga kode tetap rapi dan modular:

1. **`lib/models/product.dart`**:
   - Berisi definisi class model data `Product` untuk merepresentasikan properti produk seperti `id`, `name`, `price`, `description`, `icon`, dan `themeColor`.
   - Menggunakan package `Equatable` untuk memudahkan perbandingan objek produk demi memvalidasi kecocokan item di dalam keranjang belanja.

2. **`lib/cubit/cart_state.dart`**:
   - Mendefinisikan state-state yang dapat terjadi pada keranjang belanja.
   - Mengimplementasikan state utama `CartLoaded` yang memuat struktur data `Map<Product, int>` (memetakan produk ke jumlah kuantitasnya).
   - Menyediakan getter helper `totalPrice` untuk menghitung subtotal harga secara otomatis dan `totalItems` untuk menghitung jumlah kuantitas produk dalam keranjang secara real-time.

3. **`lib/cubit/cart_cubit.dart`**:
   - Bertindak sebagai pengontrol logika bisnis utama (*State Controller*).
   - Menyediakan fungsi `addToCart(Product product)` untuk menambah/menambah kuantitas produk, `removeFromCart(Product product)` untuk mengurangi/menghapus kuantitas produk, `removeProductCompletely(Product product)` untuk menghapus total item tertentu, serta `clearCart()` untuk mengosongkan keranjang.

4. **`lib/screens/product_list_screen.dart`**:
   - Halaman katalog utama toko yang dirancang dengan layout GridView 2 kolom bermaterial design modern.
   - Menggunakan `BlocBuilder<CartCubit, CartState>` pada AppBar untuk menampilkan jumlah item di badge belanja secara real-time.
   - Tombol tambah (+) di setiap card produk memanggil event `addToCart` pada Cubit dan menampilkan umpan balik berupa `SnackBar` dengan opsi `UNDO`.

5. **`lib/screens/cart_screen.dart`**:
   - Halaman detail keranjang belanja yang menampilkan daftar produk yang ditambahkan, kuantitas individual, opsi ubah jumlah (+/-), dan opsi hapus instan.
   - Menampilkan total ringkasan belanjaan dan tombol mock checkout.
   - Menyediakan tampilan *Empty State* yang elegan jika tidak ada barang di dalam keranjang.

6. **`lib/main.dart`**:
   - Berperan sebagai entry point utama aplikasi.
   - Membungkus seluruh aplikasi menggunakan `BlocProvider` agar instance `CartCubit` dapat diakses oleh seluruh sub-halaman secara global tanpa memicu pembuatan instansi ganda.

---

### III. PENJELASAN IMPLEMENTASI STATE MANAGEMENT CUBIT

Mekanisme state management dalam aplikasi ini bekerja sebagai berikut:

```mermaid
graph TD
    A[UI: ProductListScreen / CartScreen] -- "Memicu Event (contoh: addToCart/removeFromCart)" --> B[CartCubit]
    B -- "Memperbarui Data & Emit State Baru" --> C[CartLoaded State]
    C -- "Mengirim State Baru" --> D[BlocBuilder di UI]
    D -- "Membangun Ulang Komponen UI (Badge/Total/Kuantitas)" --> A
```

1. **Inisialisasi**: Saat aplikasi dimulai, `BlocProvider` membungkus `MaterialApp` dan menginisialisasi `CartCubit` dengan state awal `CartLoaded(items: {})`.
2. **Triggering Event**: Ketika user mengetuk tombol tambah atau kurangi pada item, UI memanggil method yang ada di Cubit:
   ```dart
   context.read<CartCubit>().addToCart(product);
   ```
3. **State Mutation**: `CartCubit` menerima instruksi tersebut, mengkopi isi map item keranjang yang lama, memperbarui nilai kuantitas, kemudian memanggil method `emit` dengan membawa objek `CartLoaded` baru.
4. **Rebuilding UI**: `BlocBuilder` yang mendengarkan perubahan pada `CartCubit` akan menerima state baru. Karena state-nya berubah (diidentifikasi melalui perbandingan nilai oleh `Equatable`), widget-widget spesifik seperti badge jumlah keranjang pada App Bar dan baris list kuantitas di halaman keranjang akan memicu render ulang secara otomatis untuk memperbarui antarmuka pengguna secara real-time.

---

### IV. DOKUMENTASI IMPLEMENTASI (SCREENSHOT)

Berikut adalah visualisasi antarmuka aplikasi yang dirancang dengan estetika premium modern:

#### 1. Tampilan Daftar Produk (Product List Screen)
*Deskripsi: Menampilkan antarmuka katalog produk teknologi dengan grid modern. Di bagian kanan atas (AppBar), terdapat ikon tas belanja dengan badge merah yang menunjukkan jumlah item aktual di dalam keranjang. Terdapat penanda jumlah item di pojok kanan atas setiap card jika produk tersebut sudah ada di keranjang.*

![Product List Mockup Image](assets/product_list.png)

---

#### 2. Tampilan Keranjang Belanja (Cart Screen)
*Deskripsi: Menampilkan halaman belanjaan yang berisi produk yang telah dipilih, lengkap dengan tombol penambahan/pengurangan kuantitas item secara individual, tombol hapus produk, serta ringkasan subtotal harga di bagian bawah dan tombol checkout.*

![Cart Mockup Image](assets/cart.png)
