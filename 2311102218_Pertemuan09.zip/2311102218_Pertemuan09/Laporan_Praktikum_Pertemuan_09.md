# LAPORAN PRAKTIKUM
## MODUL 12 & 13: STATE MANAGEMENT PROVIDER & FIREBASE CLOUD MESSAGING (FCM)

**Nama Mahasiswa:** [Nama Anda]  
**NIM:** 2311102218  
**Mata Kuliah:** Aplikasi Bergerak dan Pervasive (ABP)  
**Program Studi:** S1 Informatika  

---

### I. DESKRIPSI TUGAS
Praktikum ini bertujuan untuk membuat sebuah aplikasi Flutter sederhana yang mengintegrasikan dua konsep utama:
1. **State Management Provider**: Digunakan untuk mengelola state data daftar tugas (To-Do List). Aplikasi menyediakan fitur untuk melihat daftar tugas, menambah tugas baru, menghapus tugas tertentu, serta menghapus seluruh tugas secara massal.
2. **Firebase Cloud Messaging (FCM)**: Digunakan untuk mengintegrasikan layanan push notification ke dalam aplikasi, memungkinkan aplikasi menerima pesan notifikasi baik ketika berada di foreground maupun background.

---

### II. STRUKTUR & PENJELASAN KODE SUMBER

Aplikasi dibagi menjadi beberapa file terstruktur guna menerapkan arsitektur *Separation of Concerns* (SoC):

1. **`lib/main.dart`**:
   - Berperan sebagai entry point utama aplikasi.
   - Menginisialisasi Firebase Core dan mengaktifkan `NotificationService`.
   - Menggunakan `MultiProvider` di root widget (`MyApp`) untuk menyediakan instance `TodoProvider` dan `NotificationService` ke seluruh widget tree.
   - Menyajikan antarmuka pengguna (UI) modern dengan tema gelap premium (Deep Slate/Indigo).
   - Menyediakan UI daftar tugas, dialog input bottom-sheet, area monitoring status FCM Token, tombol salin token, dan visualisasi log notifikasi masuk.
   - Menyediakan fitur simulasi notifikasi lokal untuk memudahkan pengujian.

2. **`lib/todo_provider.dart`**:
   - Mendefinisikan class `TodoItem` dengan atribut `title` (judul tugas) dan `createdAt` (waktu pembuatan).
   - Mendefinisikan class `TodoProvider` (turunan `ChangeNotifier`) yang menampung list tugas.
   - Menyediakan method `addTodo()` untuk menambah tugas, `removeTodo()` untuk menghapus satu tugas, dan `clearAll()` untuk menghapus seluruh tugas. Masing-masing method memanggil `notifyListeners()` untuk memperbarui tampilan UI secara otomatis.

3. **`lib/notification_service.dart`**:
   - Mengelola seluruh logika notifikasi, baik lokal (`flutter_local_notifications`) maupun push notification (`firebase_messaging`).
   - Menerapkan fungsi background handler `@pragma('vm:entry-point')` untuk menangkap notifikasi saat aplikasi ditutup.
   - Meminta izin notifikasi pengguna pada runtime (Android 13+).
   - Memperoleh FCM Token dari server Firebase dan menampilkannya di UI.
   - Menyediakan method `simulateNotification()` untuk memicu notifikasi lokal agar pengujian UI dan penerimaan notifikasi dapat dilakukan langsung.

4. **Konfigurasi Gradle & Manifest (Android)**:
   - `android/settings.gradle.kts`: Menambahkan plugin Google Services versi `4.4.1`.
   - `android/app/build.gradle.kts`: Menerapkan plugin `com.google.gms.google-services` di level aplikasi.
   - `android/app/src/main/AndroidManifest.xml`: Menambahkan permission `<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />` untuk Android 13+.

---

### III. LANGKAH-LANGKAH PENGUJIAN DAN INTEGRASI FCM

Untuk menjalankan dan melakukan pengujian push notification secara riil, ikuti langkah-langkah berikut:

1. **Konfigurasi Firebase Console**:
   - Buka [Firebase Console](https://console.firebase.google.com/).
   - Buat sebuah project baru (misal: `Pertemuan 09 ToDo`).
   - Registrasikan aplikasi Android dengan package name: `com.example.pertemuan_09`.
   - Unduh file `google-services.json` dan letakkan ke direktori:  
     `d:\Tugas Praktikum ABP\2311102218_Pertemuan09\android\app\` (menimpa file dummy yang ada).

2. **Menjalankan Aplikasi**:
   - Hubungkan HP fisik (aktifkan USB Debugging) atau jalankan Android Emulator (Pixel 7).
   - Jalankan perintah: `flutter run` di terminal.

3. **Mengambil Token FCM**:
   - Ketika aplikasi terbuka, status FCM di bagian atas akan menyala hijau, dan Token FCM akan muncul di kotak abu-abu.
   - Tekan tombol **Salin Token** di sebelah kanan token untuk menyalinnya ke clipboard.

4. **Mengirim Notifikasi via Postman (HTTP v1 API)**:
   - Buat POST request ke url Google OAuth2 untuk mendapatkan Access Token, lalu kirim ke:
     `https://fcm.googleapis.com/v1/projects/[PROJECT_ID]/messages:send`
   - Gunakan Authorization Header: `Bearer [YOUR_ACCESS_TOKEN]`.
   - Gunakan JSON Body berikut (ganti dengan Token FCM Anda):
     ```json
     {
       "message": {
         "token": "TOKEN_FCM_ANDA_YANG_DISALIN",
         "notification": {
           "title": "Tugas Praktikum Baru!",
           "body": "Modul 12 dan 13 berhasil diintegrasikan dengan FCM."
         }
       }
     }
     ```
   - *Alternatif Praktis:* Kirim langsung melalui menu **Messaging** -> **Campaigns** -> **New Campaign** -> **Notifications** di Firebase Console. Tempel Token FCM Anda untuk mengirim ke perangkat uji coba.

---

### IV. DOKUMENTASI IMPLEMENTASI (SCREENSHOT)

*Silakan tempelkan screenshot hasil pengujian Anda pada bagian di bawah ini:*

#### 1. Tampilan Daftar Tugas (To-Do List)
*Deskripsi: Menampilkan antarmuka daftar tugas dalam keadaan kosong, atau berisi beberapa tugas.*

`[TEMPELKAN SCREENSHOT TAMPILAN DAFTAR TUGAS DI SINI]`

---

#### 2. Proses Penambahan Tugas
*Deskripsi: Menampilkan proses saat menekan tombol "Tugas Baru", memunculkan dialog bottom-sheet, memasukkan nama tugas, dan menekan simpan.*

`[TEMPELKAN SCREENSHOT PROSES PENAMBAHAN TUGAS DI SINI]`

---

#### 3. Notifikasi yang Berhasil Diterima Aplikasi
*Deskripsi: Menampilkan notifikasi push (FCM) yang masuk ke system tray Android (atas layar) atau yang tercatat pada log notifikasi masuk di bagian bawah aplikasi.*

`[TEMPELKAN SCREENSHOT NOTIFIKASI FCM DI SINI]`
*(Tips: Jika Anda menguji di emulator tanpa setup Firebase Console penuh, Anda dapat menggunakan tombol "Simulasi" di aplikasi untuk membuktikan fungsionalitas penayangan notifikasi lokal).*
