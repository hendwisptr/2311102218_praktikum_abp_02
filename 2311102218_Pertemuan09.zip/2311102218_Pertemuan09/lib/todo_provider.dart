import 'package:flutter/material.dart';

class TodoItem {
  final String title;
  final DateTime createdAt;

  TodoItem({
    required this.title,
    required this.createdAt,
  });
}

class TodoProvider with ChangeNotifier {
  final List<TodoItem> _todos = [];

  List<TodoItem> get todos => List.unmodifiable(_todos);

  int get count => _todos.length;

  void addTodo(String title) {
    if (title.trim().isEmpty) return;
    _todos.add(TodoItem(
      title: title.trim(),
      createdAt: DateTime.now(),
    ));
    notifyListeners();
  }

  void removeTodo(int index) {
    if (index >= 0 && index < _todos.length) {
      _todos.removeAt(index);
      notifyListeners();
    }
  }

  void clearAll() {
    _todos.clear();
    notifyListeners();
  }
}
