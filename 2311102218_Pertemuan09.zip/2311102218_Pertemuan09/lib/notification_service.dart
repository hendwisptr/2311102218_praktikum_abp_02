import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// Top-level background message handler
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Initialize Firebase if not already initialized
  await Firebase.initializeApp();
  print("Handling a background message: ${message.messageId}");
}

class NotificationService extends ChangeNotifier {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _localNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  String? _fcmToken;
  String? get fcmToken => _fcmToken;

  final List<Map<String, String>> _notificationLogs = [];
  List<Map<String, String>> get notificationLogs => List.unmodifiable(_notificationLogs);

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  Future<void> init() async {
    if (_isInitialized) return;

    // 1. Initialize Flutter Local Notifications
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
    );

    await _localNotificationsPlugin.initialize(
      settings: initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        print("Notification clicked: ${response.payload}");
      },
    );

    // Create Notification Channel for Android 8.0+
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'fcm_default_channel', // id
      'High Importance Notifications', // title
      description: 'This channel is used for important notifications.', // description
      importance: Importance.high,
      playSound: true,
    );

    await _localNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    // 2. Initialize Firebase Messaging (wrap in try-catch to prevent crash if Firebase not configured yet)
    try {
      // Set background handler
      FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

      // Request permissions
      NotificationSettings settings = await FirebaseMessaging.instance.requestPermission(
        alert: true,
        announcement: false,
        badge: true,
        carPlay: false,
        criticalAlert: false,
        provisional: false,
        sound: true,
      );

      print('User granted permission: ${settings.authorizationStatus}');

      // Get Token
      _fcmToken = await FirebaseMessaging.instance.getToken();
      print("FCM Token: $_fcmToken");
      notifyListeners();

      // Listen for token refresh
      FirebaseMessaging.instance.onTokenRefresh.listen((token) {
        _fcmToken = token;
        print("FCM Token Refreshed: $_fcmToken");
        notifyListeners();
      });

      // Handle Foreground Messages
      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        print('Got a message whilst in the foreground!');
        print('Message data: ${message.data}');

        if (message.notification != null) {
          print('Message also contained a notification: ${message.notification!.title}');
          
          // Log it
          _addLog(
            message.notification!.title ?? 'No Title',
            message.notification!.body ?? 'No Body',
            'FCM Foreground',
          );

          // Show local notification
          showLocalNotification(
            id: message.hashCode,
            title: message.notification!.title ?? 'New Message',
            body: message.notification!.body ?? '',
            payload: 'fcm_payload',
          );
        }
      });

      // Handle Message Taps when App is Opened from Background
      FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
        print('A new onMessageOpenedApp event was published!');
        _addLog(
          message.notification?.title ?? 'Tapped Notification',
          message.notification?.body ?? 'App opened from background',
          'FCM Opened App',
        );
      });

      _isInitialized = true;
    } catch (e) {
      print("Firebase FCM Initialization failed (possibly missing google-services.json): $e");
      _fcmToken = "Missing google-services.json (FCM Unavailable)";
      notifyListeners();
    }
  }

  void _addLog(String title, String body, String type) {
    _notificationLogs.insert(0, {
      'title': title,
      'body': body,
      'type': type,
      'time': DateTime.now().toString().split('.').first.substring(11),
    });
    notifyListeners();
  }

  // Show Local Notification
  Future<void> showLocalNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'fcm_default_channel',
      'High Importance Notifications',
      channelDescription: 'This channel is used for important notifications.',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
      playSound: true,
    );

    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await _localNotificationsPlugin.show(
      id: id,
      title: title,
      body: body,
      notificationDetails: platformChannelSpecifics,
      payload: payload,
    );
  }

  // Trigger simulated notification
  Future<void> simulateNotification(String title, String body) async {
    _addLog(title, body, 'Simulated');
    await showLocalNotification(
      id: DateTime.now().millisecond,
      title: title,
      body: body,
      payload: 'simulated_payload',
    );
  }

  // Clear logs
  void clearLogs() {
    _notificationLogs.clear();
    notifyListeners();
  }
}
