<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ShopController extends Controller
{
    /**
     * Display the shopping catalog for customers.
     */
    public function index()
    {
        $products = Product::all();
        return view('shop.index', compact('products'));
    }

    /**
     * Handle the product purchase.
     */
    public function buy(Request $request, Product $product)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1',
        ]);

        $quantity = $request->quantity;

        // Check stock availability
        if ($product->stock < $quantity) {
            return redirect()->back()->withErrors([
                'quantity' => "Stok tidak mencukupi. Hanya tersedia {$product->stock} unit."
            ]);
        }

        // Deduct stock
        $product->stock -= $quantity;
        $product->save();

        // Create transaction record
        Transaction::create([
            'user_id' => Auth::id(),
            'product_id' => $product->id,
            'quantity' => $quantity,
            'total_price' => $product->price * $quantity,
        ]);

        return redirect()->route('shop.index')->with('success', "Sukses belanja {$quantity} {$product->name}!");
    }

    /**
     * Display the transaction/purchase history.
     */
    public function history()
    {
        $user = Auth::user();

        if ($user->role === 'owner') {
            // Owner sees all transactions in the store
            $transactions = Transaction::with(['user', 'product'])->latest()->get();
        } else {
            // Customers see only their own purchases
            $transactions = Transaction::with(['product'])
                ->where('user_id', $user->id)
                ->latest()
                ->get();
        }

        return view('shop.history', compact('transactions'));
    }
}
