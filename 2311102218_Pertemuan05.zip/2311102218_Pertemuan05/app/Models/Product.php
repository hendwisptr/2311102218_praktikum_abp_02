<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    // Tambahkan ini agar stock (dan lainnya) bisa disimpan ke DB
    protected $fillable = [
        'name',
        'description',
        'price',
        'stock',
    ];
}
