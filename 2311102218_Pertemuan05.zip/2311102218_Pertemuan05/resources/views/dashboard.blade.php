<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-bold text-2xl text-slate-800 leading-tight">
                {{ __('Dashboard') }}
            </h2>
            <span class="px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-red-100 text-red-800 border border-red-200">
                Role: {{ Auth::user()->role === 'owner' ? 'Mas Wowo (Owner)' : 'Pak Cokomi (Customer)' }}
            </span>
        </div>
    </x-slot>

    <div class="py-12 bg-slate-50 min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-8">
            
            <!-- Welcome Banner (Red to Rose Gradient with White Text) -->
            <div class="relative overflow-hidden bg-gradient-to-r from-red-600 to-rose-700 rounded-2xl shadow-lg p-8 md:p-12 text-white">
                <div class="relative z-10 max-w-2xl">
                    <h3 class="text-3xl md:text-4xl font-extrabold mb-2">Selamat Datang, {{ Auth::user()->name }}!</h3>
                    <p class="text-white/80 text-lg">
                        {{ Auth::user()->role === 'owner' 
                            ? 'Kelola inventaris barang toko Anda secara real-time dan pantau perkembangan penjualan Mas Wowo.' 
                            : 'Temukan produk-produk menarik di toko Mas Wowo dan belanja kebutuhan Anda di sini.' }}
                    </p>
                    <div class="mt-6">
                        @if (Auth::user()->role === 'owner')
                            <a href="{{ route('products.index') }}" class="inline-flex items-center px-5 py-2.5 bg-white text-red-600 font-bold rounded-lg shadow hover:bg-slate-100 transition duration-150">
                                Kelola Produk
                            </a>
                        @else
                            <a href="{{ route('shop.index') }}" class="inline-flex items-center px-5 py-2.5 bg-white text-red-600 font-bold rounded-lg shadow hover:bg-slate-100 transition duration-150">
                                Mulai Belanja
                            </a>
                        @endif
                    </div>
                </div>
                <!-- Abstract Background Shapes -->
                <div class="absolute right-0 top-0 translate-x-12 -translate-y-12 opacity-10">
                    <svg width="400" height="400" viewBox="0 0 100 100" fill="currentColor">
                        <circle cx="50" cy="50" r="40" />
                    </svg>
                </div>
            </div>

            <!-- Stats Grid (Red & White Accents) -->
            @if (Auth::user()->role === 'owner')
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Stat Card 1 -->
                    <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-6 flex items-center space-x-4">
                        <div class="p-4 rounded-lg bg-red-50 text-red-600">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-slate-400 font-medium uppercase">Total Jenis Produk</p>
                            <h4 class="text-3xl font-bold text-slate-700">{{ $stats['total_products'] }}</h4>
                        </div>
                    </div>
                    <!-- Stat Card 2 -->
                    <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-6 flex items-center space-x-4">
                        <div class="p-4 rounded-lg bg-red-50 text-red-600">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-slate-400 font-medium uppercase">Total Pendapatan</p>
                            <h4 class="text-3xl font-bold text-slate-700">Rp {{ number_format($stats['total_sales'], 0, ',', '.') }}</h4>
                        </div>
                    </div>
                    <!-- Stat Card 3 -->
                    <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-6 flex items-center space-x-4">
                        <div class="p-4 rounded-lg bg-red-50 text-red-600">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-slate-400 font-medium uppercase">Total Produk Terjual</p>
                            <h4 class="text-3xl font-bold text-slate-700">{{ $stats['items_sold'] }} unit</h4>
                        </div>
                    </div>
                </div>
            @else
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Stat Card 1 -->
                    <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-6 flex items-center space-x-4">
                        <div class="p-4 rounded-lg bg-red-50 text-red-600">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-slate-400 font-medium uppercase">Total Belanjaan</p>
                            <h4 class="text-3xl font-bold text-slate-700">{{ $stats['total_purchases'] }} kali</h4>
                        </div>
                    </div>
                    <!-- Stat Card 2 -->
                    <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-6 flex items-center space-x-4">
                        <div class="p-4 rounded-lg bg-red-50 text-red-600">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-slate-400 font-medium uppercase">Total Pengeluaran</p>
                            <h4 class="text-3xl font-bold text-slate-700">Rp {{ number_format($stats['total_spent'], 0, ',', '.') }}</h4>
                        </div>
                    </div>
                    <!-- Stat Card 3 -->
                    <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-6 flex items-center space-x-4">
                        <div class="p-4 rounded-lg bg-red-50 text-red-600">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-slate-400 font-medium uppercase">Barang Dibeli</p>
                            <h4 class="text-3xl font-bold text-slate-700">{{ $stats['items_bought'] }} unit</h4>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Recent Activity Card -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div class="p-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                    <h4 class="font-bold text-lg text-slate-700">Aktivitas Transaksi Terkini</h4>
                    <a href="{{ route('shop.history') }}" class="text-sm font-bold text-red-600 hover:text-red-700">
                        Lihat Semua History &rarr;
                    </a>
                </div>
                <div class="p-6">
                    @if (Auth::user()->role === 'owner')
                        @if ($stats['recent_transactions']->isEmpty())
                            <p class="text-slate-400 text-center py-6">Belum ada aktivitas penjualan di toko Anda.</p>
                        @else
                            <div class="overflow-x-auto">
                                <table class="w-full text-left border-collapse">
                                    <thead>
                                        <tr class="border-b border-slate-100 text-slate-400 text-sm font-semibold uppercase">
                                            <th class="pb-3 font-semibold">Pelanggan</th>
                                            <th class="pb-3 font-semibold">Produk</th>
                                            <th class="pb-3 font-semibold text-center">Jumlah</th>
                                            <th class="pb-3 font-semibold text-right">Total Harga</th>
                                            <th class="pb-3 font-semibold text-right">Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-50">
                                        @foreach ($stats['recent_transactions'] as $tx)
                                            <tr class="text-slate-600">
                                                <td class="py-4 font-medium text-slate-800">{{ $tx->user->name }}</td>
                                                <td class="py-4">{{ $tx->product->name ?? 'Produk Dihapus' }}</td>
                                                <td class="py-4 text-center">{{ $tx->quantity }}</td>
                                                <td class="py-4 text-right font-semibold text-slate-800">Rp {{ number_format($tx->total_price, 0, ',', '.') }}</td>
                                                <td class="py-4 text-right text-sm text-slate-400">{{ $tx->created_at->diffForHumans() }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    @else
                        @if ($stats['my_recent_purchases']->isEmpty())
                            <p class="text-slate-400 text-center py-6">Anda belum pernah melakukan pembelian.</p>
                        @else
                            <div class="overflow-x-auto">
                                <table class="w-full text-left border-collapse">
                                    <thead>
                                        <tr class="border-b border-slate-100 text-slate-400 text-sm font-semibold uppercase">
                                            <th class="pb-3 font-semibold">Produk</th>
                                            <th class="pb-3 font-semibold text-center">Jumlah</th>
                                            <th class="pb-3 font-semibold text-right">Total Bayar</th>
                                            <th class="pb-3 font-semibold text-right">Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-50">
                                        @foreach ($stats['my_recent_purchases'] as $tx)
                                            <tr class="text-slate-600">
                                                <td class="py-4 font-medium text-slate-800">{{ $tx->product->name ?? 'Produk Dihapus' }}</td>
                                                <td class="py-4 text-center">{{ $tx->quantity }}</td>
                                                <td class="py-4 text-right font-semibold text-red-600">Rp {{ number_format($tx->total_price, 0, ',', '.') }}</td>
                                                <td class="py-4 text-right text-sm text-slate-400">{{ $tx->created_at->diffForHumans() }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    @endif
                </div>
            </div>

        </div>
    </div>
</x-app-layout>
