<x-app-layout>
    <x-slot name="header">
        <h2 class="font-bold text-2xl text-slate-800 leading-tight">
            {{ Auth::user()->role === 'owner' ? __('Laporan Penjualan Toko') : __('Riwayat Belanja Anda') }}
        </h2>
    </x-slot>

    <div class="py-12 bg-slate-50 min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Context Header Info -->
            <div class="mb-6">
                <h3 class="text-lg font-bold text-slate-700">
                    {{ Auth::user()->role === 'owner' ? 'Daftar Penjualan Barang' : 'Daftar Barang yang Telah Dibeli' }}
                </h3>
                <p class="text-slate-400 text-sm">
                    {{ Auth::user()->role === 'owner' 
                        ? 'Menampilkan seluruh riwayat transaksi pembelian dari pelanggan di toko Mas Wowo.' 
                        : 'Menampilkan seluruh riwayat barang yang telah Anda belanjakan dari toko Mas Wowo.' }}
                </p>
            </div>

            <!-- Table Card -->
            <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <div class="overflow-x-auto">
                    @if ($transactions->isEmpty())
                        <div class="p-12 text-center">
                            <svg class="w-12 h-12 text-slate-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 114 0m-4 4h.01M9 16h.01"></path>
                            </svg>
                            <p class="text-slate-400 font-medium">Belum ada transaksi tercatat.</p>
                        </div>
                    @else
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="bg-slate-50 border-b border-slate-100 text-slate-500 text-xs font-bold uppercase tracking-wider">
                                    @if (Auth::user()->role === 'owner')
                                        <th class="p-4 pl-6">Pelanggan</th>
                                    @endif
                                    <th class="p-4 {{ Auth::user()->role !== 'owner' ? 'pl-6' : '' }}">Produk</th>
                                    <th class="p-4 text-center">Jumlah</th>
                                    <th class="p-4 text-right">Total Transaksi</th>
                                    <th class="p-4 text-right pr-6">Waktu & Tanggal</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                @foreach ($transactions as $tx)
                                    <tr class="hover:bg-slate-50/50 transition-colors duration-150 text-slate-600">
                                        @if (Auth::user()->role === 'owner')
                                            <td class="p-4 pl-6">
                                                <div class="font-semibold text-slate-800">{{ $tx->user->name }}</div>
                                                <div class="text-xs text-slate-400">{{ $tx->user->email }}</div>
                                            </td>
                                        @endif
                                        <td class="p-4 {{ Auth::user()->role !== 'owner' ? 'pl-6' : '' }}">
                                            @if ($tx->product)
                                                <div class="font-bold text-slate-800">{{ $tx->product->name }}</div>
                                                <div class="text-xs text-slate-400">Harga Satuan: Rp {{ number_format($tx->product->price, 0, ',', '.') }}</div>
                                            @else
                                                <div class="font-bold text-rose-600">Produk Telah Dihapus</div>
                                            @endif
                                        </td>
                                        <td class="p-4 text-center font-medium">
                                            {{ $tx->quantity }} unit
                                        </td>
                                        <td class="p-4 text-right font-extrabold text-red-600">
                                            Rp {{ number_format($tx->total_price, 0, ',', '.') }}
                                        </td>
                                        <td class="p-4 text-right pr-6 text-sm text-slate-500">
                                            <div>{{ $tx->created_at->setTimezone('Asia/Jakarta')->format('d M Y, H:i') }}</div>
                                            <div class="text-xs text-slate-400">{{ $tx->created_at->diffForHumans() }}</div>
                                        </td>
                                    </tr>
                                </endforeach
                            </tbody>
                        </table>
                    @endif
                </div>
            </div>

        </div>
    </div>
</x-app-layout>
