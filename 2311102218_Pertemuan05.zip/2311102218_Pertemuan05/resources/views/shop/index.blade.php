<x-app-layout>
    <x-slot name="header">
        <h2 class="font-bold text-2xl text-slate-800 leading-tight">
            {{ __('Toko Belanja Mas Wowo') }}
        </h2>
    </x-slot>

    <div class="py-12 bg-slate-50 min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Alert Success / Info -->
            @if (session('success'))
                <div class="mb-8 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl flex items-center space-x-3 shadow-sm">
                    <svg class="w-5 h-5 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span class="font-medium text-sm">{{ session('success') }}</span>
                </div>
            @endif

            @if ($errors->any())
                <div class="mb-8 p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-start space-x-3 shadow-sm">
                    <svg class="w-5 h-5 text-rose-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div class="text-sm font-medium">
                        <ul class="list-disc pl-5 space-y-1">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endif

            <!-- Catalog Section -->
            <div class="mb-6">
                <h3 class="text-lg font-bold text-slate-700">Katalog Produk</h3>
                <p class="text-slate-400 text-sm">Pilih produk berkualitas di bawah ini untuk dibeli. Stok akan otomatis berkurang setelah transaksi berhasil.</p>
            </div>

            @if ($products->isEmpty())
                <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-12 text-center">
                    <p class="text-slate-400">Toko sedang kosong. Mas Wowo belum menambahkan produk apa pun.</p>
                </div>
            @else
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    @foreach ($products as $product)
                        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-shadow duration-200 flex flex-col justify-between">
                            
                            <!-- Card Body -->
                            <div class="p-6">
                                <!-- Tag / Icon Placeholder (Red-White theme) -->
                                <div class="w-12 h-12 rounded-xl bg-red-50 text-red-600 flex items-center justify-center mb-4 font-bold text-lg">
                                    {{ strtoupper(substr($product->name, 0, 2)) }}
                                </div>
                                
                                <h4 class="font-extrabold text-slate-800 text-lg mb-1 leading-snug">{{ $product->name }}</h4>
                                <p class="text-slate-500 text-xs line-clamp-3 mb-4 leading-relaxed h-12 overflow-hidden">
                                    {{ $product->description ?: 'Tidak ada deskripsi untuk produk ini.' }}
                                </p>

                                <div class="flex justify-between items-center mb-4">
                                    <span class="text-red-600 font-extrabold text-lg">
                                        Rp {{ number_format($product->price, 0, ',', '.') }}
                                    </span>
                                    
                                    @if ($product->stock <= 0)
                                        <span class="px-2.5 py-1 text-xs font-bold bg-rose-50 border border-rose-100 text-rose-700 rounded-full">Habis</span>
                                    @elseif ($product->stock <= 5)
                                        <span class="px-2.5 py-1 text-xs font-bold bg-amber-50 border border-amber-100 text-amber-700 rounded-full">Sisa {{ $product->stock }}</span>
                                    @else
                                        <span class="px-2.5 py-1 text-xs font-bold bg-emerald-50 border border-emerald-100 text-emerald-700 rounded-full">Stok: {{ $product->stock }}</span>
                                    @endif
                                </div>
                            </div>

                            <!-- Card Footer Form -->
                            <div class="p-6 pt-0 border-t border-slate-50 bg-slate-50/50">
                                @if ($product->stock > 0)
                                    <form action="{{ route('shop.buy', $product->id) }}" method="POST" class="mt-4 space-y-3">
                                        @csrf
                                        <div class="flex items-center space-x-2">
                                            <label for="quantity-{{ $product->id }}" class="text-xs font-semibold text-slate-400">Qty:</label>
                                            <input 
                                                id="quantity-{{ $product->id }}"
                                                type="number" 
                                                name="quantity" 
                                                value="1" 
                                                min="1" 
                                                max="{{ $product->stock }}" 
                                                class="w-full px-3 py-1 border border-slate-200 focus:outline-none focus:ring-1 focus:ring-red-500 focus:border-red-500 rounded-lg text-sm text-center text-slate-700"
                                            />
                                        </div>
                                        <button 
                                            type="submit" 
                                            class="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-sm transition-colors duration-150 shadow-md shadow-red-100"
                                        >
                                            Belanja
                                        </button>
                                    </form>
                                @else
                                    <div class="mt-4">
                                        <button 
                                            disabled 
                                            class="w-full py-2.5 bg-slate-200 text-slate-400 font-bold rounded-xl text-sm cursor-not-allowed"
                                        >
                                            Stok Habis
                                        </button>
                                    </div>
                                @endif
                            </div>

                        </div>
                    @endforeach
                </div>
            @endif

        </div>
    </div>
</x-app-layout>
