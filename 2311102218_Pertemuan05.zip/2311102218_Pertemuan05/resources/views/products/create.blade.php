<x-app-layout>
    <x-slot name="header">
        <h2 class="font-bold text-2xl text-slate-800 leading-tight">
            {{ __('Tambah Produk Baru') }}
        </h2>
    </x-slot>

    <div class="py-12 bg-slate-50 min-h-screen">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            
            <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-8">
                <div class="mb-6 border-b border-slate-100 pb-4">
                    <h3 class="text-lg font-bold text-slate-700">Form Inventaris Barang</h3>
                    <p class="text-slate-400 text-sm">Masukkan detail produk untuk ditambahkan ke toko Mas Wowo.</p>
                </div>

                <form method="POST" action="{{ route('products.store') }}" class="space-y-6">
                    @csrf

                    <!-- Nama Produk -->
                    <div>
                        <x-input-label for="name" :value="__('Nama Produk')" class="font-semibold text-slate-700" />
                        <x-text-input id="name" class="block mt-1 w-full border-slate-200 focus:ring-red-500 focus:border-red-500 rounded-lg text-slate-700 shadow-sm" type="text" name="name" :value="old('name')" required autofocus placeholder="Contoh: Kopi Gayo Premium" />
                        <x-input-error :messages="$errors->get('name')" class="mt-2" />
                    </div>

                    <!-- Deskripsi -->
                    <div>
                        <x-input-label for="description" :value="__('Deskripsi Produk (Opsional)')" class="font-semibold text-slate-700" />
                        <textarea id="description" name="description" rows="4" class="block mt-1 w-full border-slate-200 focus:ring-red-500 focus:border-red-500 rounded-lg text-slate-700 shadow-sm text-sm" placeholder="Jelaskan mengenai keunggulan, rasa, atau kemasan produk ini...">{{ old('description') }}</textarea>
                        <x-input-error :messages="$errors->get('description')" class="mt-2" />
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Harga -->
                        <div>
                            <x-input-label for="price" :value="__('Harga (Rupiah)')" class="font-semibold text-slate-700" />
                            <div class="relative mt-1">
                                <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 font-bold text-sm">
                                    Rp
                                </span>
                                <x-text-input id="price" class="block w-full pl-10 border-slate-200 focus:ring-red-500 focus:border-red-500 rounded-lg text-slate-700 shadow-sm" type="number" name="price" :value="old('price')" required placeholder="Contoh: 15000" />
                            </div>
                            <x-input-error :messages="$errors->get('price')" class="mt-2" />
                        </div>

                        <!-- Stok -->
                        <div>
                            <x-input-label for="stock" :value="__('Stok Awal')" class="font-semibold text-slate-700" />
                            <x-text-input id="stock" class="block mt-1 w-full border-slate-200 focus:ring-red-500 focus:border-red-500 rounded-lg text-slate-700 shadow-sm" type="number" name="stock" :value="old('stock')" required placeholder="Contoh: 50" />
                            <x-input-error :messages="$errors->get('stock')" class="mt-2" />
                        </div>
                    </div>

                    <!-- Buttons -->
                    <div class="flex items-center justify-end space-x-3 border-t border-slate-100 pt-6 mt-8">
                        <a href="{{ route('products.index') }}" class="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-sm transition">
                            Batal
                        </a>
                        <button type="submit" class="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-sm transition shadow-md shadow-red-100">
                            Simpan Produk
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</x-app-layout>