<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ShopController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    $user = auth()->user();
    $stats = [];
    if ($user->role === 'owner') {
        $stats['total_products'] = \App\Models\Product::count();
        $stats['total_sales'] = \App\Models\Transaction::sum('total_price');
        $stats['items_sold'] = \App\Models\Transaction::sum('quantity');
        $stats['recent_transactions'] = \App\Models\Transaction::with(['user', 'product'])->latest()->take(5)->get();
    } else {
        $stats['total_spent'] = \App\Models\Transaction::where('user_id', $user->id)->sum('total_price');
        $stats['total_purchases'] = \App\Models\Transaction::where('user_id', $user->id)->count();
        $stats['items_bought'] = \App\Models\Transaction::where('user_id', $user->id)->sum('quantity');
        $stats['my_recent_purchases'] = \App\Models\Transaction::with('product')->where('user_id', $user->id)->latest()->take(5)->get();
    }
    return view('dashboard', compact('stats'));
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // Shared transaction history route
    Route::get('/history', [ShopController::class, 'history'])->name('shop.history');
});

// Owner only routes
Route::middleware(['auth', 'role:owner'])->group(function () {
    Route::resource('products', ProductController::class);
});

// Customer only routes
Route::middleware(['auth', 'role:customer'])->group(function () {
    Route::get('/shop', [ShopController::class, 'index'])->name('shop.index');
    Route::post('/shop/buy/{product}', [ShopController::class, 'buy'])->name('shop.buy');
});

require __DIR__.'/auth.php';
