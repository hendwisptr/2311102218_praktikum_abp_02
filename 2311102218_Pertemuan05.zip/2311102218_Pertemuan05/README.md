# Aplikasi Inventaris & Belanja Toko (Mas Wowo & Pak Cokomi)

Aplikasi berbasis web menggunakan framework **Laravel 12**, **Tailwind CSS**, dan **Alpine.js** yang dirancang untuk memenuhi kebutuhan sistem manajemen inventaris toko (Mas Wowo) dan modul belanja pelanggan (Pak Cokomi). Aplikasi ini mengintegrasikan sistem autentikasi bawaan **Laravel Breeze** dengan pembagian hak akses (role) dinamis.

---

## 🌟 Fitur Utama Aplikasi

### 1. Sistem Autentikasi Multi-Role (Laravel Breeze)
- **Role Owner (Mas Wowo)**: Memiliki hak penuh untuk mengelola inventaris produk dan memantau transaksi penjualan.
- **Role Customer (Pak Cokomi)**: Memiliki hak khusus untuk melihat katalog belanja, melakukan pembelian barang, dan memantau riwayat belanja pribadinya.

### 2. Panel Dashboard Premium
- **Tampilan Owner**: Menampilkan metrik total produk terdaftar, total pendapatan penjualan (dalam Rupiah), total barang terjual, serta daftar transaksi terbaru dari seluruh pelanggan.
- **Tampilan Customer**: Menampilkan metrik total transaksi belanja, total pengeluaran belanja (dalam Rupiah), jumlah barang dibeli, dan daftar riwayat belanja terbaru miliknya.

### 3. Kelola Produk (CRUD Inventaris - Khusus Mas Wowo)
- **Tampilan Tabel Premium**: Desain tabel modern dengan hover transitions, badge indikator status stok (Stok Habis, Stok Kritis, dan Stok Tersedia).
- **Pencarian Real-Time**: Fitur filter pencarian produk secara instan tanpa reload halaman menggunakan Alpine.js.
- **Form Create & Edit Modern**: Dilengkapi dengan input penamaan produk, deskripsi panjang, nominal harga, kuantitas stok, dan umpan balik error validasi form.
- **Modal Konfirmasi Hapus**: Fitur konfirmasi penghapusan barang menggunakan modal interaktif (Alpine.js) untuk mencegah ketidaksengajaan klik hapus.

### 4. Modul Toko Belanja (Khusus Pak Cokomi)
- **Katalog Belanja Grid**: Kartu produk (product card) yang responsif dengan badge status ketersediaan barang.
- **Transaksi Pembelian & Pengurangan Stok**: Pak Cokomi dapat menentukan jumlah barang yang ingin dibeli. Jika stok mencukupi, sistem akan otomatis mengurangi stok produk dan mencatat transaksi ke database. Jika melebihi stok, sistem akan menampilkan pesan validasi error.

### 5. Laporan & Riwayat Transaksi (Shared View)
- **Laporan Penjualan (Owner)**: Mas Wowo dapat melihat laporan lengkap mengenai siapa pelanggan yang membeli, barang apa yang dibeli, kuantitas, total harga, dan waktu pembelian.
- **Riwayat Belanja (Customer)**: Pak Cokomi dapat melihat histori pembelian pribadinya beserta detail harga satuan, total transaksi, dan waktu pembelian.

---

## 🔑 Kredensial Akun Default (Seeded)

Gunakan akun berikut untuk melakukan pengujian sistem setelah melakukan seeding database:

| Peran (Role) | Nama | Email | Password |
| :--- | :--- | :--- | :--- |
| **Owner / Pemilik Toko** | Mas Wowo | `wowo@gmail.com` | `password` |
| **Customer / Pelanggan** | Pak Cokomi | `cokomi@gmail.com` | `password` |

---

## 🛠️ Panduan Instalasi dan Menjalankan Proyek

Ikuti langkah-langkah berikut untuk menjalankan aplikasi di lokal komputer Anda:

### 1. Clone & Buka Direktori Proyek
Pastikan PHP (>= 8.2), Composer, dan Node.js sudah terinstal.

### 2. Instalasi Dependensi PHP
```bash
composer install
```

### 3. Salin Konfigurasi Environment & Konfigurasi SQLite
```bash
cp .env.example .env
```
Secara default, proyek ini menggunakan database **SQLite**. Konfigurasi `.env` telah disetel ke `DB_CONNECTION=sqlite`. File database `database/database.sqlite` akan otomatis terdeteksi atau dibuat oleh Laravel.

### 4. Generate App Key
```bash
php artisan key:generate
```

### 5. Jalankan Migrasi & Database Seeder (Paling Penting!)
Langkah ini akan membuat tabel, menambahkan kolom role, serta memasukkan data default Mas Wowo, Pak Cokomi, dan produk contoh dari Factory:
```bash
php artisan migrate:fresh --seed
```

### 6. Instalasi & Kompilasi Aset Frontend (CSS/JS)
```bash
npm install
npm run build
```

### 7. Jalankan Server Lokal
```bash
php artisan serve
```
Buka peramban (browser) Anda dan akses alamat `http://127.0.0.1:8000`.

---

## 📂 Struktur Database Proyek

### Tabel `users`
Menyimpan data akun pengguna dengan penambahan kolom `role`:
- `id` (Primary Key)
- `name` (string)
- `email` (string, unique)
- `password` (string)
- `role` (string, default: `customer`) - Berisi `'owner'` atau `'customer'`
- `timestamps`

### Tabel `products`
Menyimpan data inventaris barang dagangan:
- `id` (Primary Key)
- `name` (string)
- `description` (text, nullable)
- `price` (integer)
- `stock` (integer)
- `timestamps`

### Tabel `transactions`
Menyimpan histori transaksi belanja:
- `id` (Primary Key)
- `user_id` (Foreign Key -> `users.id`, cascade)
- `product_id` (Foreign Key -> `products.id`, cascade)
- `quantity` (integer)
- `total_price` (integer)
- `timestamps`
