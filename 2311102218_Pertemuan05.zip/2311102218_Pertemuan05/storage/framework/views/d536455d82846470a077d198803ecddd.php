<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-bold text-2xl text-slate-800 leading-tight">
                <?php echo e(__('Inventaris Toko')); ?>

            </h2>
            <a href="<?php echo e(route('products.create')); ?>" class="inline-flex items-center px-4 py-2 bg-red-600 border border-transparent rounded-lg font-bold text-sm text-white uppercase tracking-wider hover:bg-red-700 active:bg-red-800 focus:outline-none focus:border-red-950 focus:ring ring-red-300 transition duration-150 ease-in-out shadow-md shadow-red-100">
                + Tambah Produk
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-slate-50 min-h-screen" x-data="{ search: '', showDeleteModal: false, deleteUrl: '' }">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Alert Success -->
            <?php if(session('success')): ?>
                <div class="mb-6 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl flex items-center space-x-3 shadow-sm">
                    <svg class="w-5 h-5 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <!-- Search Bar Card -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-6 mb-6">
                <div class="relative max-w-md">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </span>
                    <input 
                        type="text" 
                        x-model="search" 
                        placeholder="Cari produk berdasarkan nama..." 
                        class="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-lg text-slate-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition duration-150 text-sm"
                    />
                </div>
            </div>

            <!-- Table Card -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-slate-50 border-b border-slate-100 text-slate-500 text-xs font-bold uppercase tracking-wider">
                                <th class="p-4 pl-6">Nama Produk</th>
                                <th class="p-4">Deskripsi</th>
                                <th class="p-4 text-right">Harga</th>
                                <th class="p-4 text-center">Stok</th>
                                <th class="p-4 text-center pr-6">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-slate-50/50 transition-colors duration-150" x-show="search === '' || '<?php echo e(strtolower($product->name)); ?>'.includes(search.toLowerCase())">
                                    <td class="p-4 pl-6">
                                        <div class="font-bold text-slate-800"><?php echo e($product->name); ?></div>
                                    </td>
                                    <td class="p-4 text-slate-500 text-sm max-w-xs truncate">
                                        <?php echo e($product->description ?: '-'); ?>

                                    </td>
                                    <td class="p-4 text-right font-semibold text-slate-800">
                                        Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                                    </td>
                                    <td class="p-4 text-center">
                                        <?php if($product->stock <= 0): ?>
                                            <span class="inline-flex px-2 py-0.5 rounded-full text-xs font-bold bg-rose-50 border border-rose-100 text-rose-800">
                                                Habis
                                            </span>
                                        <?php elseif($product->stock <= 5): ?>
                                            <span class="inline-flex px-2 py-0.5 rounded-full text-xs font-bold bg-amber-50 border border-amber-100 text-amber-800">
                                                Kritis (<?php echo e($product->stock); ?>)
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-50 border border-emerald-100 text-emerald-800">
                                                <?php echo e($product->stock); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-4 text-center pr-6">
                                        <div class="flex justify-center items-center space-x-3">
                                            <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="text-red-600 hover:text-red-700 transition font-bold text-sm">
                                                Edit
                                            </a>
                                            <span class="text-slate-300">|</span>
                                            <button 
                                                type="button" 
                                                @click="showDeleteModal = true; deleteUrl = '<?php echo e(route('products.destroy', $product->id)); ?>'" 
                                                class="text-rose-600 hover:text-rose-700 transition font-bold text-sm"
                                            >
                                                Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="p-8 text-center text-slate-400">
                                        Belum ada produk terdaftar. Klik "+ Tambah Produk" untuk memulai.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Custom Delete Modal -->
        <div 
            x-show="showDeleteModal" 
            class="fixed inset-0 z-50 flex items-center justify-center overflow-auto bg-slate-900/50 backdrop-blur-sm" 
            x-cloak
            x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0"
        >
            <div 
                @click.away="showDeleteModal = false" 
                class="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden border border-slate-100 transform transition-all"
                x-show="showDeleteModal"
                x-transition:enter="transition ease-out duration-300"
                x-transition:enter-start="opacity-0 scale-95 translate-y-4"
                x-transition:enter-end="opacity-100 scale-100 translate-y-0"
                x-transition:leave="transition ease-in duration-200"
                x-transition:leave-start="opacity-100 scale-100 translate-y-0"
                x-transition:leave-end="opacity-0 scale-95 translate-y-4"
            >
                <div class="p-6">
                    <div class="flex items-center space-x-3 text-rose-500 mb-4">
                        <div class="p-2 bg-rose-50 rounded-full">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                            </svg>
                        </div>
                        <h3 class="text-lg font-extrabold text-slate-800">Hapus Produk?</h3>
                    </div>
                    <p class="text-slate-500 text-sm mb-6 leading-relaxed">
                        Apakah Anda yakin ingin menghapus produk ini dari daftar inventaris? Tindakan ini bersifat permanen dan data transaksi lama yang berkaitan mungkin akan terpengaruh.
                    </p>
                    <div class="flex justify-end space-x-3">
                        <button 
                            type="button" 
                            @click="showDeleteModal = false" 
                            class="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-sm transition"
                        >
                            Batal
                        </button>
                        <form :action="deleteUrl" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button 
                                type="submit" 
                                class="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg text-sm transition shadow-md shadow-red-100"
                            >
                                Ya, Hapus
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Codingan\2311102218_Pertemuan05\resources\views/products/index.blade.php ENDPATH**/ ?>