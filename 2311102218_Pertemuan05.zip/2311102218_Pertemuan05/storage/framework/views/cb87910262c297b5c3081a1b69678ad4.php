<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-2xl text-slate-800 leading-tight">
            <?php echo e(__('Toko Belanja Mas Wowo')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-slate-50 min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Alert Success / Info -->
            <?php if(session('success')): ?>
                <div class="mb-8 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl flex items-center space-x-3 shadow-sm">
                    <svg class="w-5 h-5 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="mb-8 p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-start space-x-3 shadow-sm">
                    <svg class="w-5 h-5 text-rose-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div class="text-sm font-medium">
                        <ul class="list-disc pl-5 space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Catalog Section -->
            <div class="mb-6">
                <h3 class="text-lg font-bold text-slate-700">Katalog Produk</h3>
                <p class="text-slate-400 text-sm">Pilih produk berkualitas di bawah ini untuk dibeli. Stok akan otomatis berkurang setelah transaksi berhasil.</p>
            </div>

            <?php if($products->isEmpty()): ?>
                <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-12 text-center">
                    <p class="text-slate-400">Toko sedang kosong. Mas Wowo belum menambahkan produk apa pun.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-shadow duration-200 flex flex-col justify-between">
                            
                            <!-- Card Body -->
                            <div class="p-6">
                                <!-- Tag / Icon Placeholder (Red-White theme) -->
                                <div class="w-12 h-12 rounded-xl bg-red-50 text-red-600 flex items-center justify-center mb-4 font-bold text-lg">
                                    <?php echo e(strtoupper(substr($product->name, 0, 2))); ?>

                                </div>
                                
                                <h4 class="font-extrabold text-slate-800 text-lg mb-1 leading-snug"><?php echo e($product->name); ?></h4>
                                <p class="text-slate-500 text-xs line-clamp-3 mb-4 leading-relaxed h-12 overflow-hidden">
                                    <?php echo e($product->description ?: 'Tidak ada deskripsi untuk produk ini.'); ?>

                                </p>

                                <div class="flex justify-between items-center mb-4">
                                    <span class="text-red-600 font-extrabold text-lg">
                                        Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                                    </span>
                                    
                                    <?php if($product->stock <= 0): ?>
                                        <span class="px-2.5 py-1 text-xs font-bold bg-rose-50 border border-rose-100 text-rose-700 rounded-full">Habis</span>
                                    <?php elseif($product->stock <= 5): ?>
                                        <span class="px-2.5 py-1 text-xs font-bold bg-amber-50 border border-amber-100 text-amber-700 rounded-full">Sisa <?php echo e($product->stock); ?></span>
                                    <?php else: ?>
                                        <span class="px-2.5 py-1 text-xs font-bold bg-emerald-50 border border-emerald-100 text-emerald-700 rounded-full">Stok: <?php echo e($product->stock); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Card Footer Form -->
                            <div class="p-6 pt-0 border-t border-slate-50 bg-slate-50/50">
                                <?php if($product->stock > 0): ?>
                                    <form action="<?php echo e(route('shop.buy', $product->id)); ?>" method="POST" class="mt-4 space-y-3">
                                        <?php echo csrf_field(); ?>
                                        <div class="flex items-center space-x-2">
                                            <label for="quantity-<?php echo e($product->id); ?>" class="text-xs font-semibold text-slate-400">Qty:</label>
                                            <input 
                                                id="quantity-<?php echo e($product->id); ?>"
                                                type="number" 
                                                name="quantity" 
                                                value="1" 
                                                min="1" 
                                                max="<?php echo e($product->stock); ?>" 
                                                class="w-full px-3 py-1 border border-slate-200 focus:outline-none focus:ring-1 focus:ring-red-500 focus:border-red-500 rounded-lg text-sm text-center text-slate-700"
                                            />
                                        </div>
                                        <button 
                                            type="submit" 
                                            class="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-sm transition-colors duration-150 shadow-md shadow-red-100"
                                        >
                                            Belanja
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <div class="mt-4">
                                        <button 
                                            disabled 
                                            class="w-full py-2.5 bg-slate-200 text-slate-400 font-bold rounded-xl text-sm cursor-not-allowed"
                                        >
                                            Stok Habis
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Codingan\2311102218_Pertemuan05\resources\views/shop/index.blade.php ENDPATH**/ ?>