const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }));

// Konek Database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'db_inventaris'
});
db.connect((err) => {
    if (err) throw err;
    console.log('Database Connected!');
});

// Routing Halaman
app.get('/', (req, res) => res.render('home')); // Halaman 1: Home
app.get('/data', (req, res) => res.render('data')); // Halaman 2: Tabel

// API JSON
app.get('/api/barang', (req, res) => {
    db.query('SELECT * FROM barang', (err, results) => {
        if (err) throw err;
        res.json({ data: results });
    });
});


// Form Tambah
app.get('/form', (req, res) => res.render('form', { barang: null }));

// Form Edit
app.get('/edit/:id', (req, res) => {
    db.query('SELECT * FROM barang WHERE id = ?', [req.params.id], (err, results) => {
        if (err) throw err;
        res.render('form', { barang: results[0] });
    });
});

// Create
app.post('/simpan', (req, res) => {
    const { nama_barang, kategori, stok, harga } = req.body;
    db.query('INSERT INTO barang (nama_barang, kategori, stok, harga) VALUES (?, ?, ?, ?)', 
    [nama_barang, kategori, stok, harga], () => res.redirect('/data'));
});

// Update
app.post('/update/:id', (req, res) => {
    const { nama_barang, kategori, stok, harga } = req.body;
    db.query('UPDATE barang SET nama_barang=?, kategori=?, stok=?, harga=? WHERE id=?', 
    [nama_barang, kategori, stok, harga, req.params.id], () => res.redirect('/data'));
});

// Delete
app.get('/hapus/:id', (req, res) => {
    db.query('DELETE FROM barang WHERE id = ?', [req.params.id], () => res.redirect('/data'));
});


app.listen(3000, () => console.log('Server berjalan di http://localhost:3000'));