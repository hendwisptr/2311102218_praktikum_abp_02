import 'package:flutter/material.dart';
import 'dart:math' as math;

void main() {
  runApp(const WidgetShowcaseApp());
}

class WidgetShowcaseApp extends StatelessWidget {
  const WidgetShowcaseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Widget Showcase',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6366F1), // Indigo
          brightness: Brightness.dark,
        ),
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5),
          bodyLarge: TextStyle(color: Colors.white70),
        ),
      ),
      themeMode: ThemeMode.dark, // Sleek dark mode by default
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const HomeScreen(),
    const ContainerDemoScreen(),
    const GridViewDemoScreen(),
    const ListViewDemoScreen(),
    const ListViewBuilderDemoScreen(),
    const ListViewSeparatedDemoScreen(),
    const StackDemoScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // Navigation Rail for desktop/web, adaptable for all screens
          NavigationRail(
            selectedIndex: _selectedIndex > 6 ? 0 : _selectedIndex,
            onDestinationSelected: (int index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            labelType: NavigationRailLabelType.selected,
            backgroundColor: const Color(0xFF1E1E2E),
            indicatorColor: const Color(0xFF6366F1).withOpacity(0.3),
            selectedIconTheme: const IconThemeData(color: Color(0xFF818CF8)),
            unselectedIconTheme: const IconThemeData(color: Colors.white30),
            selectedLabelTextStyle: const TextStyle(
              color: Color(0xFF818CF8),
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
            unselectedLabelTextStyle: const TextStyle(
              color: Colors.white30,
              fontSize: 11,
            ),
            destinations: const [
              NavigationRailDestination(
                icon: Icon(Icons.dashboard_rounded),
                selectedIcon: Icon(Icons.dashboard_rounded),
                label: Text('Beranda'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.crop_square_rounded),
                selectedIcon: Icon(Icons.check_box_outline_blank_rounded),
                label: Text('Container'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.grid_view_rounded),
                selectedIcon: Icon(Icons.grid_view_rounded),
                label: Text('GridView'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.format_list_bulleted_rounded),
                selectedIcon: Icon(Icons.format_list_bulleted_rounded),
                label: Text('ListView'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.reorder_rounded),
                selectedIcon: Icon(Icons.reorder_rounded),
                label: Text('L.Builder'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.splitscreen_rounded),
                selectedIcon: Icon(Icons.splitscreen_rounded),
                label: Text('L.Separated'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.layers_rounded),
                selectedIcon: Icon(Icons.layers_rounded),
                label: Text('Stack'),
              ),
            ],
          ),
          const VerticalDivider(thickness: 1, width: 1, color: Colors.white12),
          // Main Content
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: _screens[_selectedIndex],
            ),
          ),
        ],
      ),
    );
  }
}

// Widget Explanation Banner Helper
class ExplanationBanner extends StatelessWidget {
  final String title;
  final String description;
  final List<String> parameters;

  const ExplanationBanner({
    super.key,
    required this.title,
    required this.description,
    required this.parameters,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF312E81), // Deep Indigo
            const Color(0xFF1E1B4B),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF4338CA), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.info_outline, color: Color(0xFF818CF8), size: 24),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            description,
            style: const TextStyle(fontSize: 14, color: Colors.white70, height: 1.5),
          ),
          const SizedBox(height: 12),
          const Text(
            'Atribut Kunci:',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFFC7D2FE)),
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: parameters.map((param) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF4F46E5).withOpacity(0.3),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFF6366F1).withOpacity(0.5)),
                ),
                child: Text(
                  param,
                  style: const TextStyle(fontSize: 12, fontFamily: 'monospace', color: Color(0xFFE0E7FF)),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

// ----------------------------------------------------
// SCREEN 0: HOME / DASHBOARD
// ----------------------------------------------------
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F1A),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Profile Card (Student Info)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6366F1), Color(0xFF4F46E5), Color(0xFF3730A3)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF6366F1).withOpacity(0.4),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Text(
                            'Tugas Praktikum ABP',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        const Icon(Icons.school, color: Colors.white, size: 28),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Flutter Widget Showcase',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Modul 7: Implementasi Berbagai UI Widget',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Divider(color: Colors.white30, height: 1),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const CircleAvatar(
                          radius: 24,
                          backgroundColor: Colors.white,
                          child: Text(
                            'ABP',
                            style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4F46E5)),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'Mahasiswa: Hendwi Saputra (NIM: 2311102218)',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            Text(
                              'Kelas: IF-11-02',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ],
                    )
                  ],
                ),
              ),
              const SizedBox(height: 32),
              const Text(
                'Daftar Widget yang Didemonstrasikan',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 16),
              // List of Widgets with links
              _buildWidgetListTile(
                context,
                title: '1. Container',
                subtitle: 'Kotak dekoratif dengan gradient, border, shadow, dan transform.',
                icon: Icons.crop_square_rounded,
                color: const Color(0xFFEC4899),
              ),
              _buildWidgetListTile(
                context,
                title: '2. GridView',
                subtitle: 'Menampilkan item dalam bentuk baris dan kolom (minimal 6 item).',
                icon: Icons.grid_view_rounded,
                color: const Color(0xFF3B82F6),
              ),
              _buildWidgetListTile(
                context,
                title: '3. ListView',
                subtitle: 'Daftar item statis (A, B, C) dengan visual kartu yang menarik.',
                icon: Icons.format_list_bulleted_rounded,
                color: const Color(0xFF10B981),
              ),
              _buildWidgetListTile(
                context,
                title: '4. ListView.builder',
                subtitle: 'Daftar item dinamis yang dibuat dari data array secara efisien.',
                icon: Icons.reorder_rounded,
                color: const Color(0xFFF59E0B),
              ),
              _buildWidgetListTile(
                context,
                title: '5. ListView.separated',
                subtitle: 'Daftar item dinamis yang memiliki garis pembatas kustom.',
                icon: Icons.splitscreen_rounded,
                color: const Color(0xFF8B5CF6),
              ),
              _buildWidgetListTile(
                context,
                title: '6. Stack',
                subtitle: 'Menyusun elemen secara bertumpuk untuk membuat tata letak kustom.',
                icon: Icons.layers_rounded,
                color: const Color(0xFFEF4444),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWidgetListTile(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E2E),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        leading: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 24),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(fontSize: 12, color: Colors.white54),
        ),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white30, size: 16),
      ),
    );
  }
}

// ----------------------------------------------------
// SCREEN 1: CONTAINER DEMO
// ----------------------------------------------------
class ContainerDemoScreen extends StatefulWidget {
  const ContainerDemoScreen({super.key});

  @override
  State<ContainerDemoScreen> createState() => _ContainerDemoScreenState();
}

class _ContainerDemoScreenState extends State<ContainerDemoScreen> {
  double _borderRadius = 16.0;
  double _padding = 24.0;
  double _rotation = 0.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F1A),
      appBar: AppBar(
        title: const Text('Container Demonstration'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ExplanationBanner(
              title: 'Widget: Container',
              description:
                  'Container adalah widget serbaguna yang menggabungkan pengepasan (sizing), margin, padding, dekorasi (warna latar belakang, border, bayangan, dll.), dan transformasi posisi/ukuran.',
              parameters: ['width', 'height', 'margin', 'padding', 'decoration', 'transform', 'alignment'],
            ),
            const SizedBox(height: 10),
            // Sandbox Controls
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E2E),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Interactive Controls', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Text('Border Radius: ', style: TextStyle(fontSize: 12)),
                      Expanded(
                        child: Slider(
                          value: _borderRadius,
                          min: 0,
                          max: 60,
                          onChanged: (val) => setState(() => _borderRadius = val),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text('Internal Padding: ', style: TextStyle(fontSize: 12)),
                      Expanded(
                        child: Slider(
                          value: _padding,
                          min: 8,
                          max: 48,
                          onChanged: (val) => setState(() => _padding = val),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text('Rotation: ', style: TextStyle(fontSize: 12)),
                      Expanded(
                        child: Slider(
                          value: _rotation,
                          min: 0,
                          max: 360,
                          onChanged: (val) => setState(() => _rotation = val),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            // The Container Demo Box
            Center(
              child: Transform.rotate(
                angle: _rotation * math.pi / 180,
                child: Container(
                  width: 220,
                  height: 220,
                  padding: EdgeInsets.all(_padding),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFEC4899), Color(0xFF8B5CF6)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(_borderRadius),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFEC4899).withOpacity(0.4),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                    border: Border.all(color: Colors.white.withOpacity(0.3), width: 2),
                  ),
                  child: const Text(
                    'Container',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      shadows: [
                        Shadow(color: Colors.black45, offset: Offset(2, 2), blurRadius: 4),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------
// SCREEN 2: GRIDVIEW DEMO
// ----------------------------------------------------
class GridViewDemoScreen extends StatefulWidget {
  const GridViewDemoScreen({super.key});

  @override
  State<GridViewDemoScreen> createState() => _GridViewDemoScreenState();
}

class _GridViewDemoScreenState extends State<GridViewDemoScreen> {
  int _columns = 2;

  final List<Map<String, dynamic>> _gridItems = [
    {'title': 'Analytics', 'icon': Icons.analytics_rounded, 'color': const Color(0xFF3B82F6), 'desc': 'Track insights'},
    {'title': 'Database', 'icon': Icons.storage_rounded, 'color': const Color(0xFF10B981), 'desc': 'Manage storage'},
    {'title': 'Security', 'icon': Icons.security_rounded, 'color': const Color(0xFFEF4444), 'desc': 'Safe connections'},
    {'title': 'Cloud', 'icon': Icons.cloud_done_rounded, 'color': const Color(0xFF06B6D4), 'desc': 'Sync services'},
    {'title': 'Messaging', 'icon': Icons.forum_rounded, 'color': const Color(0xFFF59E0B), 'desc': 'Chat active'},
    {'title': 'Settings', 'icon': Icons.settings_brightness_rounded, 'color': const Color(0xFF8B5CF6), 'desc': 'Personalize UI'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F1A),
      appBar: AppBar(
        title: const Text('GridView Demonstration'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ExplanationBanner(
              title: 'Widget: GridView',
              description:
                  'GridView digunakan untuk menyusun widget anak dalam bentuk tabel dua dimensi (baris dan kolom). Berguna untuk membuat menu dashboard atau galeri.',
              parameters: ['gridDelegate', 'crossAxisCount', 'mainAxisSpacing', 'crossAxisSpacing', 'childAspectRatio'],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Layout Kolom Grid:', style: TextStyle(fontWeight: FontWeight.bold)),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 2, label: Text('2 Kolom')),
                    ButtonSegment(value: 3, label: Text('3 Kolom')),
                  ],
                  selected: {_columns},
                  onSelectionChanged: (set) => setState(() => _columns = set.first),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: _columns,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: _columns == 2 ? 1.3 : 1.0,
                ),
                itemCount: _gridItems.length,
                itemBuilder: (context, index) {
                  final item = _gridItems[index];
                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1E2E),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: item['color'].withOpacity(0.3), width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: item['color'].withOpacity(0.05),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(item['icon'], color: item['color'], size: 32),
                        const SizedBox(height: 10),
                        Text(
                          item['title'],
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item['desc'],
                          style: const TextStyle(fontSize: 11, color: Colors.white54),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------
// SCREEN 3: LISTVIEW DEMO (A, B, C)
// ----------------------------------------------------
class ListViewDemoScreen extends StatelessWidget {
  const ListViewDemoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F1A),
      appBar: AppBar(
        title: const Text('ListView (A, B, C)'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const ExplanationBanner(
            title: 'Widget: ListView',
            description:
                'ListView adalah jenis daftar linear yang menggulir paling umum digunakan. Model ini memuat semua anak sekaligus, cocok untuk daftar pendek/statis seperti formulir atau menu terbatas.',
            parameters: ['children', 'scrollDirection', 'reverse', 'physics'],
          ),
          const SizedBox(height: 10),
          _buildItemCard(
            title: 'Item A: Tahap Perencanaan',
            subtitle: 'Merancang arsitektur sistem, memetakan spesifikasi teknis, serta merumuskan kebutuhan widget UI.',
            label: 'A',
            gradient: const [Color(0xFFEC4899), Color(0xFFF43F5E)],
          ),
          _buildItemCard(
            title: 'Item B: Tahap Implementasi',
            subtitle: 'Menulis kode program Flutter, mengintegrasikan widget UI, dan mengaktifkan kontrol interaktif.',
            label: 'B',
            gradient: const [Color(0xFF3B82F6), Color(0xFF2563EB)],
          ),
          _buildItemCard(
            title: 'Item C: Tahap Verifikasi',
            subtitle: 'Menguji performa aplikasi, memeriksa responsivitas UI, dan menangkap tangkapan layar (screenshot).',
            label: 'C',
            gradient: const [Color(0xFF10B981), Color(0xFF059669)],
          ),
        ],
      ),
    );
  }

  Widget _buildItemCard({
    required String title,
    required String subtitle,
    required String label,
    required List<Color> gradient,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E2E),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(color: gradient[0].withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4)),
                ],
              ),
              alignment: Alignment.center,
              child: Text(
                label,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 13, color: Colors.white60, height: 1.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------
// SCREEN 4: LISTVIEW BUILDER DEMO
// ----------------------------------------------------
class ListViewBuilderDemoScreen extends StatefulWidget {
  const ListViewBuilderDemoScreen({super.key});

  @override
  State<ListViewBuilderDemoScreen> createState() => _ListViewBuilderDemoScreenState();
}

class _ListViewBuilderDemoScreenState extends State<ListViewBuilderDemoScreen> {
  final List<String> _notifications = [
    'Tugas praktikum ABP berhasil disubmit ke server lokal.',
    'Pembaruan flutter versi terbaru siap untuk diinstal.',
    'Review kode dari dosen pengampu telah masuk.',
    'Perangkat Android Emulator berhasil dijalankan.',
    'Perubahan commit berhasil dideploy ke repository git.',
  ];

  void _addNotification() {
    setState(() {
      int nextNum = _notifications.length + 1;
      _notifications.insert(0, 'Pemberitahuan Baru #$nextNum: Aksi berhasil dipicu dari demo.');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F1A),
      appBar: AppBar(
        title: const Text('ListView.builder'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline_rounded, color: Color(0xFF818CF8)),
            onPressed: _addNotification,
            tooltip: 'Tambah Pemberitahuan',
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ExplanationBanner(
              title: 'Widget: ListView.builder',
              description:
                  'ListView.builder secara dinamis merender item daftar sesuai permintaan (lazy loading). Sangat efisien untuk memuat kumpulan data yang besar atau tidak terbatas secara dinamis dari array.',
              parameters: ['itemCount', 'itemBuilder', 'scrollDirection', 'shrinkWrap'],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Riwayat Log Aplikasi (${_notifications.length} item)',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                TextButton.icon(
                  onPressed: _addNotification,
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Simulasi Log', style: TextStyle(fontSize: 12)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: _notifications.length,
                itemBuilder: (context, index) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1E2E),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white.withOpacity(0.04)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.notifications_active_outlined, color: Color(0xFFF59E0B), size: 20),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _notifications[index],
                                style: const TextStyle(fontSize: 13, color: Colors.white),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Indeks data ke-$index',
                                style: const TextStyle(fontSize: 11, color: Colors.white30),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------
// SCREEN 5: LISTVIEW SEPARATED DEMO
// ----------------------------------------------------
class ListViewSeparatedDemoScreen extends StatelessWidget {
  const ListViewSeparatedDemoScreen({super.key});

  final List<Map<String, dynamic>> _settingsItems = const [
    {'title': 'Profil Pengguna', 'subtitle': 'Informasi akun & konfigurasi biodata', 'icon': Icons.person_outline},
    {'title': 'Keamanan Akun', 'subtitle': 'Ubah kata sandi & otentikasi dua arah', 'icon': Icons.lock_outline},
    {'title': 'Notifikasi', 'subtitle': 'Pemberitahuan push & preferensi suara', 'icon': Icons.notifications_none},
    {'title': 'Tema & Desain', 'subtitle': 'Mode gelap, skema warna, & layout', 'icon': Icons.palette_outlined},
    {'title': 'Bahasa Sistem', 'subtitle': 'Bahasa Indonesia, English, dll.', 'icon': Icons.language_outlined},
    {'title': 'Bantuan & FAQ', 'subtitle': 'Pusat bantuan & tanya jawab', 'icon': Icons.help_outline},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F1A),
      appBar: AppBar(
        title: const Text('ListView.separated'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ExplanationBanner(
              title: 'Widget: ListView.separated',
              description:
                  'Sama seperti ListView.builder, namun memiliki tambahan parameter separatorBuilder untuk menyisipkan pemisah visual (misalnya Divider) secara otomatis di antara setiap item.',
              parameters: ['itemCount', 'itemBuilder', 'separatorBuilder'],
            ),
            const Text(
              'Pengaturan Aplikasi',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1E2E),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.04)),
                ),
                child: ListView.separated(
                  itemCount: _settingsItems.length,
                  separatorBuilder: (context, index) => Divider(
                    color: Colors.white.withOpacity(0.06),
                    height: 1,
                    indent: 64,
                    endIndent: 16,
                  ),
                  itemBuilder: (context, index) {
                    final item = _settingsItems[index];
                    return ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      leading: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF8B5CF6).withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(item['icon'], color: const Color(0xFF8B5CF6), size: 20),
                      ),
                      title: Text(
                        item['title'],
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white),
                      ),
                      subtitle: Text(
                        item['subtitle'],
                        style: const TextStyle(fontSize: 12, color: Colors.white30),
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded, color: Colors.white24),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------
// SCREEN 6: STACK DEMO
// ----------------------------------------------------
class StackDemoScreen extends StatefulWidget {
  const StackDemoScreen({super.key});

  @override
  State<StackDemoScreen> createState() => _StackDemoScreenState();
}

class _StackDemoScreenState extends State<StackDemoScreen> {
  bool _showOverlay = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F1A),
      appBar: AppBar(
        title: const Text('Stack Demonstration'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ExplanationBanner(
              title: 'Widget: Stack',
              description:
                  'Stack menyusun elemen anak secara bertumpuk (overlapped) berdasarkan urutan kodenya (indeks bawah ditumpuk oleh indeks atas). Widget Positioned atau Align biasa digunakan untuk mengatur koordinat anak di dalamnya.',
              parameters: ['alignment', 'fit', 'clipBehavior', 'children'],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Tampilkan Overlay Badge:', style: TextStyle(fontWeight: FontWeight.bold)),
                Switch(
                  value: _showOverlay,
                  activeColor: const Color(0xFFEF4444),
                  onChanged: (val) => setState(() => _showOverlay = val),
                ),
              ],
            ),
            const SizedBox(height: 20),
            // Stack Showcase Card
            Center(
              child: SizedBox(
                width: 320,
                height: 240,
                child: Stack(
                  children: [
                    // Layer 1: Background Card with Gradient
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF1E1B4B), Color(0xFF312E81)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white.withOpacity(0.08), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.4),
                              blurRadius: 15,
                              offset: const Offset(0, 8),
                            )
                          ],
                        ),
                      ),
                    ),
                    // Layer 2: Decorative Circle (Ornaments)
                    Positioned(
                      right: -30,
                      top: -30,
                      child: Container(
                        width: 140,
                        height: 140,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF818CF8).withOpacity(0.12),
                        ),
                      ),
                    ),
                    // Layer 3: Main Profile Info
                    Positioned(
                      left: 24,
                      top: 40,
                      child: Row(
                        children: [
                          // Profile Picture with dynamic status badge
                          Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Container(
                                width: 70,
                                height: 70,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: const Color(0xFFEF4444), width: 2),
                                  gradient: const LinearGradient(
                                    colors: [Color(0xFFEF4444), Color(0xFFF43F5E)],
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: const Icon(Icons.person, color: Colors.white, size: 40),
                              ),
                              if (_showOverlay)
                                Positioned(
                                  right: 0,
                                  bottom: 0,
                                  child: Container(
                                    width: 18,
                                    height: 18,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF10B981), // Green active badge
                                      shape: BoxShape.circle,
                                      border: Border.all(color: const Color(0xFF1E1B4B), width: 2),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(width: 16),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text(
                                'Hendwi Saputra',
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white),
                              ),
                              Text(
                                'App Developer',
                                style: TextStyle(fontSize: 13, color: Colors.white54),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    // Layer 4: Floating Stats Badge at the bottom
                    Positioned(
                      bottom: 24,
                      left: 24,
                      right: 24,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.05)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Text('Proyek: 14 Aktif', style: TextStyle(fontSize: 12, color: Colors.white70)),
                            Text('Skor: 9.8 / 10', style: TextStyle(fontSize: 12, color: Colors.white70)),
                          ],
                        ),
                      ),
                    ),
                    // Layer 5: Premium Ribon (Floating absolute positioned text)
                    Positioned(
                      top: 16,
                      right: 16,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEF4444),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          'PRO',
                          style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
