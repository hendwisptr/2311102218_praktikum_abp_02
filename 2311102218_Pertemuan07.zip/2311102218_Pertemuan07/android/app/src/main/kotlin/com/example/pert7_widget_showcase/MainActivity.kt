package com.example.pert7_widget_showcase

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
