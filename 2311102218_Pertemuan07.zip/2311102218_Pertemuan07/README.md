# Tugas Praktikum ABP - Flutter Widget Showcase

Proyek Flutter ini dibuat untuk memenuhi tugas praktikum mata kuliah Aplikasi Berbasis Platform (ABP) - Pertemuan 7. Aplikasi ini mendemonstrasikan implementasi dari 6 widget UI dasar di Flutter menggunakan desain antarmuka modern (Dark Mode) dengan antarmuka navigasi samping (Navigation Rail) yang responsif dan interaktif.

## 👤 Informasi Mahasiswa
* **Nama**: Hendwi Saputra
* **NIM**: 2311102218
* **Kelas**: IF-11-02

---

## 🛠️ Penjelasan Singkat Tiap Widget

### 1. `Container`
* **Definisi**: Widget serbaguna yang digunakan untuk membungkus, mengatur ukuran (sizing), memberikan margin/padding, dekorasi (warna latar belakang, border, rounded corners, bayangan), serta melakukan transformasi (rotasi/skala).
* **Atribut Kunci**: `width`, `height`, `padding`, `margin`, `decoration` (menggunakan `BoxDecoration`), `transform`, dan `alignment`.
* **Implementasi**: Digunakan untuk menampilkan kotak gradient dengan sudut bulat (border radius), bayangan luar (box shadow), dan transformasi rotasi interaktif.

### 2. `GridView`
* **Definisi**: Widget yang menyusun elemen-elemen anaknya dalam bentuk tabel dua dimensi (grid baris dan kolom). Sangat cocok untuk membuat menu dashboard atau galeri item.
* **Atribut Kunci**: `gridDelegate` (mengatur layout grid seperti `SliverGridDelegateWithFixedCrossAxisCount`), `crossAxisCount` (jumlah kolom), `mainAxisSpacing` (jarak vertikal), dan `crossAxisSpacing` (jarak horizontal).
* **Implementasi**: Menampilkan menu dashboard fungsional dengan minimal 6 item (Analytics, Database, Security, Cloud, Messaging, Settings) yang tersusun rapi dan responsif.

### 3. `ListView`
* **Definisi**: Widget daftar linear yang dapat digulir (scrollable). ListView statis langsung memuat seluruh elemen anak (`children`) di memori, sehingga cocok untuk daftar yang pendek atau konten yang statis.
* **Atribut Kunci**: `children`, `scrollDirection` (arah gulir), dan `physics` (efek gulir).
* **Implementasi**: Menampilkan tepat 3 item kartu tahapan proyek (Item A: Perencanaan, Item B: Implementasi, Item C: Verifikasi) yang didesain secara premium.

### 4. `ListView.builder`
* **Definisi**: Varian ListView yang merender item secara dinamis hanya saat item tersebut terlihat di layar (*lazy loading*). Sangat efisien untuk memuat data dalam jumlah besar atau data dinamis dari array.
* **Atribut Kunci**: `itemCount` (jumlah total item) dan `itemBuilder` (fungsi untuk membuat widget berdasarkan indeks data).
* **Implementasi**: Menampilkan riwayat log/pemberitahuan aplikasi dinamis dari data array, dilengkapi dengan fitur simulasi tambah log secara real-time.

### 5. `ListView.separated`
* **Definisi**: Serupa dengan `ListView.builder`, namun dilengkapi dengan parameter khusus untuk menyisipkan widget pemisah (seperti garis pembatas `Divider`) secara otomatis di antara setiap item.
* **Atribut Kunci**: `itemCount`, `itemBuilder`, dan `separatorBuilder` (fungsi pembangun garis/pemisah).
* **Implementasi**: Menampilkan menu Pengaturan Aplikasi (Profil, Keamanan, Notifikasi, Tema, Bahasa, Bantuan) dengan garis pemisah tipis yang rapi di antaranya.

### 6. `Stack`
* **Definisi**: Widget yang digunakan untuk menyusun elemen-elemen anak secara bertumpuk satu sama lain (seperti lapisan/layer). Elemen di bawah dalam kode akan berada di posisi terbawah, sedangkan elemen selanjutnya akan ditumpuk di atasnya.
* **Atribut Kunci**: `alignment`, `children`, dan widget penolong seperti `Positioned` atau `Align` untuk mengatur koordinat absolut anak di dalam stack.
* **Implementasi**: Menampilkan kartu profil premium dengan avatar bulat yang saling bertumpuk dengan gambar latar belakang, lencana status "active" (online) di sudut avatar, lencana kategori "PRO" melayang di pojok kanan atas, serta teks status di bagian bawah.

---

## 📸 Screenshot Hasil Aplikasi

Berikut adalah hasil tangkapan layar (screenshot) dari setiap halaman widget showcase pada aplikasi:

### 📱 0. Beranda / Dashboard Utama
Menampilkan profil mahasiswa pengirim tugas dan rangkuman keenam widget yang didemonstrasikan.
![Beranda / Dashboard Utama](screenshots/0_dashboard.png)

### 📱 1. Demo Widget: Container
Menunjukkan bentuk visual `Container` kustom dengan kontrol interaktif untuk mengubah radius, padding, dan rotasi.
![Demo Container](screenshots/1_container.png)

### 📱 2. Demo Widget: GridView
Menampilkan layout grid responsif dengan 6 kartu fitur dashboard (bisa diubah layout kolomnya antara 2 dan 3 kolom).
![Demo GridView](screenshots/2_gridview.png)

### 📱 3. Demo Widget: ListView
Menampilkan daftar statis yang berisi tepat 3 item (A, B, dan C) berbentuk kartu informasi berwarna-warni.
![Demo ListView](screenshots/3_listview.png)

### 📱 4. Demo Widget: ListView.builder
Menampilkan daftar pemberitahuan dinamis yang dapat ditambah kustom secara real-time dari array data.
![Demo ListView.builder](screenshots/4_listview_builder.png)

### 📱 5. Demo Widget: ListView.separated
Menampilkan antarmuka pengaturan dengan garis pemisah (*divider*) kustom di antara setiap baris menu.
![Demo ListView.separated](screenshots/5_listview_separated.png)

### 📱 6. Demo Widget: Stack
Menampilkan kartu profil bertumpuk dengan badge online di atas avatar bulat, lencana "PRO" absolut di pojok, dan overlay info.
![Demo Stack](screenshots/6_stack.png)

---

## 🚀 Cara Menjalankan Project

1. **Pastikan Flutter SDK terinstal** di komputer Anda.
2. Clone atau buka folder repo ini melalui terminal.
3. Jalankan perintah untuk mengunduh dependencies:
   ```bash
   flutter pub get
   ```
4. Jalankan aplikasi di perangkat target (Chrome/Windows/Emulator):
   ```bash
   flutter run
   ```
