package com.example.pertemuan_08

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
