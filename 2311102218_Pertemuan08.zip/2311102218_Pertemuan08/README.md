# Tugas Praktikum ABP - Pertemuan 08
## Notifikasi & API Perangkat Keras

Proyek ini adalah aplikasi Flutter sederhana yang mendemonstrasikan integrasi perangkat keras kamera langsung (Camera API), pemilihan gambar dari galeri (`image_picker`), serta memicu notifikasi lokal (`flutter_local_notifications`).

---

## 🛠️ Fitur Utama
1. **Ambil Foto Langsung (Camera API)**: Membuka feed kamera langsung menggunakan package `camera`, merender `CameraPreview` secara real-time, dan mengambil foto menggunakan shutter button custom.
2. **Pilih Foto Galeri (Image Picker)**: Menggunakan package `image_picker` untuk menavigasi galeri perangkat dan memilih gambar yang ada.
3. **Display Gambar**: Foto yang diambil dari kamera atau dipilih dari galeri langsung ditampilkan pada layar utama (di halaman yang sama).
4. **Notifikasi Lokal**: Setelah gambar berhasil didapatkan (dari kamera atau galeri), aplikasi akan memicu notifikasi sistem lokal di perangkat Android.

---

## 📂 Struktur File Utama
```text
lib/
├── main.dart                 # Entry point aplikasi & UI halaman utama
├── camera_screen.dart        # Widget Custom Camera API (CameraPreview)
└── notification_service.dart # Helper class inisialisasi & trigger Notifikasi Lokal
```

---

## 📝 Penjelasan Source Code Singkat

### 1. `NotificationService` (`lib/notification_service.dart`)
*Kelas pembantu (helper) untuk mengelola daur hidup dan trigger notifikasi lokal di perangkat.*
* **`init()`**: Menginisialisasi `FlutterLocalNotificationsPlugin` dengan ikon bawaan Android (`@mipmap/ic_launcher`).
* **`requestPermissions()`**: Meminta izin menampilkan notifikasi ke sistem operasi Android (wajib untuk Android 13+ / API 33+).
* **`showNotification()`**: Menampilkan pesan notifikasi pop-up di layar dengan konfigurasi suara dan prioritas tinggi.

### 2. `CameraScreen` (`lib/camera_screen.dart`)
*Widget Stateful halaman kamera kustom untuk mengakses hardware kamera langsung.*
* **`_initializeCamera()`**: Mengakses lensa kamera perangkat lewat `availableCameras()`, mengatur resolusi gambar, lalu memanggil `_controller.initialize()`.
* **`CameraPreview`**: Widget untuk merender aliran data video mentah (preview) dari kamera ke layar.
* **`_takePicture()`**: Menjepret gambar menggunakan `takePicture()` dan mengembalikan path file hasil jepretan ke layar utama menggunakan `Navigator.pop(context, path)`.

### 3. `MyHomePage` (`lib/main.dart`)
*Halaman utama yang menampilkan preview gambar dan menyediakan aksi pemicu.*
* **State `_imagePath`**: String penyimpan lokasi sementara berkas gambar yang aktif.
* **Tombol pertama (Camera API)**: Membuka halaman `CameraScreen`. Jika sukses mendapat path file, state diperbarui dan notifikasi lokal *"Foto Berhasil Diambil!"* ditampilkan.
* **Tombol kedua (Image Picker)**: Mengaktifkan galeri sistem perangkat. Setelah pengguna memilih foto, state diperbarui dan notifikasi lokal *"Foto Berhasil Dipilih!"* ditampilkan.
* **Tampilan Gambar**: Responsif menampilkan `Image.file(...)` jika `_imagePath != null`, atau menampilkan placeholder bawaan jika masih kosong.

---

## ⚙️ Konfigurasi Sistem

### Android (AndroidManifest.xml)
Izin (permissions) yang dideklarasikan agar aplikasi diizinkan memakai hardware kamera dan notifikasi:
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

### SDK Min (build.gradle.kts)
Ditingkatkan ke level 21 karena didukung minimal oleh package `camera` dan `flutter_local_notifications`:
```kotlin
minSdk = 21
```
